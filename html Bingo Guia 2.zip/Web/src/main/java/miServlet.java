/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Random;

public class miServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String accion = request.getParameter("accion");
            String nombre = request.getParameter("nombre");

            if (accion == null || accion.isEmpty()) {
                // Pantalla de bienvenida (Pantalla 1)
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Bienvenida - Bingo Online</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<form action='miServlet'>");
                out.println("<h1>BIENVENIDO</h1>");
                out.println("<h1>°BINGO ONLINE°</h1>");
                out.println("<h1>Digite su nombre</h1>");
                out.println("<input type='text' id='nombre' name='nombre'>");
                out.println("<input type='submit' name='accion' value='preparacion'>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if ("preparacion".equals(accion)) {
                // Pantalla de tiempo de preparación (Pantalla 2)
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Preparación - Bingo Online</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Proximo Juego: 1.00</h1>");
                out.println("<h1>Preparese para comenzar a jugar: " + nombre + "</h1>");
                out.println("<form action='miServlet'>");
                out.println("<input type='hidden' name='nombre' value='" + nombre + "'>");
                out.println("<input type='submit' name='accion' value='juego'>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if ("juego".equals(accion)) {
                // Pantalla de juego (Pantalla 3)
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Juego - Bingo Online</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>JUGANDO BINGO</h1>");
                out.println("<h2>¡Buena suerte, " + nombre + "!</h2>");

                // Generar matriz 5x5 para el cartón de bingo
                int[][] bingoCard = generateBingoCard();
                out.println("<table border='1'>");
                String[] columnas = {"B", "I", "N", "G", "O"};
                out.println("<tr>");
                for (String col : columnas) {
                    out.println("<th>" + col + "</th>");
                }
                out.println("</tr>");
                for (int i = 0; i < 5; i++) {
                    out.println("<tr>");
                    for (int j = 0; j < 5; j++) {
                        out.println("<td>" + bingoCard[i][j] + "</td>");
                    }
                    out.println("</tr>");
                }
                out.println("</table>");

                out.println("<form action='miServlet'>");
                out.println("<input type='hidden' name='nombre' value='" + nombre + "'>");
                out.println("<input type='submit' name='accion' value='cartonLleno'>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if ("cartonLleno".equals(accion)) {
                // Pantalla de cartón lleno (Pantalla 4)
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Cartón Lleno - Bingo Online</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Cartón Lleno</h1>");
                out.println("<h2>¡Todos los números están marcados!</h2>");

                // Mostrar el cartón lleno con "X"
                out.println("<table border='1'>");
                out.println("<tr>");
                String[] columnas = {"B", "I", "N", "G", "O"};
                for (String col : columnas) {
                    out.println("<th>" + col + "</th>");
                }
                out.println("</tr>");
                for (int i = 0; i < 5; i++) {
                    out.println("<tr>");
                    for (int j = 0; j < 5; j++) {
                        out.println("<td>X</td>");
                    }
                    out.println("</tr>");
                }
                out.println("</table>");

                out.println("<form action='miServlet'>");
                out.println("<input type='hidden' name='nombre' value='" + nombre + "'>");
                out.println("<input type='submit' name='accion' value='ganador'>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if ("ganador".equals(accion)) {
                // Pantalla de ganador (Pantalla 5)
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Ganador - Bingo Online</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>¡Felicidades, " + nombre + "!</h1>");
                out.println("<h2>Has ganado el Bingo Online</h2>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    // Método para generar una matriz 5x5 de números aleatorios para el bingo
    private int[][] generateBingoCard() {
        int[][] card = new int[5][5];
        Random rand = new Random();

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                card[i][j] = rand.nextInt(15) + 1 + 15 * i; // Números en rango 1-15 para B, 16-30 para I, etc.
            }
        }
        return card;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
